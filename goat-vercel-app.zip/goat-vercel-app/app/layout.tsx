import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'G.O.A.T. — November 12, 2026',
  description: 'An interactive fan-made G.O.A.T movie experience.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
