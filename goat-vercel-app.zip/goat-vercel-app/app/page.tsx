'use client';

import { useEffect, useState } from 'react';

const cast = [
  { name: 'Sudigali Sudheer', role: 'The G.O.A.T.', image: '/images/sudheer.jpg', featured: true },
  { name: 'Female Lead', role: 'Character Reveal', image: '/images/female-lead.jpg' },
  { name: 'Motta Rajendran', role: 'Prashanth', image: '/images/rajendran.jpg' },
  { name: 'Sarvadaman D. Banerjee', role: 'Venkata Krishnam Raju', image: '/images/sarvadaman.jpg' },
  { name: 'Nithin Prasanna', role: 'Moddu Babji', image: '/images/nithin.jpg' },
  { name: 'Aadukalam Naren', role: 'Pedda Rajulu', image: '/images/naren.jpg' },
];

function Countdown() {
  const target = new Date('2026-11-12T00:00:00+05:30').getTime();
  const [left, setLeft] = useState(target - Date.now());
  useEffect(() => {
    const id = setInterval(() => setLeft(Math.max(0, target - Date.now())), 1000);
    return () => clearInterval(id);
  }, [target]);
  const days = Math.floor(left / 86400000);
  const hours = Math.floor((left / 3600000) % 24);
  const mins = Math.floor((left / 60000) % 60);
  const secs = Math.floor((left / 1000) % 60);
  return <div className="countdown"><div><b>{days}</b><span>DAYS</span></div><i>:</i><div><b>{String(hours).padStart(2,'0')}</b><span>HRS</span></div><i>:</i><div><b>{String(mins).padStart(2,'0')}</b><span>MIN</span></div><i>:</i><div><b>{String(secs).padStart(2,'0')}</b><span>SEC</span></div></div>;
}

export default function Home() {
  const [menu, setMenu] = useState(false);
  return (
    <main>
      <div className="grain" />
      <nav>
        <div className="mark"><span>G</span><small>O.A.T.</small></div>
        <div className={menu ? 'navlinks open' : 'navlinks'}>
          <a href="#story" onClick={() => setMenu(false)}>THE WORLD</a>
          <a href="#cast" onClick={() => setMenu(false)}>CAST</a>
          <a href="#release" onClick={() => setMenu(false)}>RELEASE</a>
        </div>
        <button className="menu" onClick={() => setMenu(!menu)} aria-label="menu">☰</button>
      </nav>

      <section className="hero">
        <div className="scribble s1">THE ONE<br/>WHO<br/>CHANGES<br/>THE GAME ↗</div>
        <div className="hero-copy">
          <p className="eyebrow">A NEW COMIC CINEMATIC EXPERIENCE</p>
          <h1><span>G.</span><span>O.</span><span>A.</span><span>T.</span></h1>
          <p className="tag">GREATEST OF ALL TIMES</p>
          <div className="release-chip">IN THEATRES <strong>12 NOV 2026</strong></div>
        </div>
        <div className="hero-photo-wrap">
          <div className="burst">★<br/><small>GAME<br/>ON</small></div>
          <img src="/images/sudheer.jpg" alt="G.O.A.T. lead" className="hero-photo" />
          <div className="frame-note">HYDERABAD<br/><span>ONE MAN. MANY MOVES.</span></div>
        </div>
        <div className="scribble s2">★<br/>NO<br/>RULEBOOK</div>
      </section>

      <section id="story" className="manifesto">
        <div className="section-label">01 / THE WORLD</div>
        <div className="manifesto-grid">
          <div>
            <p className="kicker">A GAME WITH NO STRAIGHT LINE</p>
            <h2>COMEDY.<br/><em>ACTION.</em><br/>ATTITUDE.</h2>
          </div>
          <div className="manifesto-copy">
            <p>Built like a hand-drawn movie wall: real faces, rough paper, street energy and the confidence of a hero who never plays by the expected rules.</p>
            <div className="rule"><span>CRICKET</span><span>CHAOS</span><span>CHARACTER</span></div>
          </div>
        </div>
        <div className="comic-strip">
          <div className="panel panel-one"><span>01</span><b>THE<br/>ENTRY</b><i>→</i></div>
          <div className="panel panel-two"><span>02</span><b>THE<br/>MOVE</b><i>↗</i></div>
          <div className="panel panel-three"><span>03</span><b>THE<br/>GAME</b><i>★</i></div>
        </div>
      </section>

      <section id="cast" className="cast-section">
        <div className="section-label">02 / CHARACTER FILES</div>
        <div className="cast-head"><h2>MEET THE<br/><em>PLAYERS.</em></h2><p>Every face gets its own frame. Every frame has a story.</p></div>
        <div className="cast-grid">
          {cast.map((person, i) => (
            <article key={person.name} className={person.featured ? 'cast-card featured' : 'cast-card'}>
              <div className="photo"><img src={person.image} alt={person.name} /></div>
              <div className="card-meta"><span>FILE {String(i+1).padStart(2,'0')}</span><b>{person.name}</b><small>AS {person.role}</small></div>
              <div className="annotation">{i % 2 === 0 ? 'WATCH THIS ONE' : 'CHARACTER FILE'} ↗</div>
            </article>
          ))}
        </div>
      </section>

      <section id="release" className="release-section">
        <div className="ticket">ADMIT ONE <span>★</span> G.O.A.T.</div>
        <p className="eyebrow">THE WAIT ENDS</p>
        <h2>NOVEMBER<br/><span>12</span></h2>
        <p className="year">2026 / THEATRES</p>
        <Countdown />
        <div className="release-bottom"><span>MAKE SOME NOISE.</span><span>GREATEST OF ALL TIMES</span></div>
      </section>

      <footer><span>G.O.A.T. / 2026</span><span>AN ORIGINAL FAN-MADE DIGITAL EXPERIENCE</span><span>★</span></footer>
    </main>
  );
}
