# G.O.A.T. Movie Vercel App

Premium fan-made interactive movie landing page for G.O.A.T., designed around the supplied cast/character images.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy to Vercel

1. Put this folder in a GitHub repository.
2. Import the repository into Vercel.
3. Framework preset: Next.js (automatic).
4. Deploy.

All supplied images are already inside `public/images`.
